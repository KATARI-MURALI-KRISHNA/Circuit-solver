import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize

x2, y2 = np.loadtxt("dataset2.txt", unpack=True)
x2=np.array(x2)
y2=np.array(y2)


def model_function(params, x, y_observed):
    A1, A2, A3, f, p1, p2, p3 = params
    y_fitted = (
        A1 * np.sin(2 * np.pi * f * x + p1)
        + A2 * np.sin(2 * np.pi * 3 * f * x + p2)
        + A3 * np.sin(2 * np.pi * 5 * f * x + p3)
    )
    return np.sum((y_fitted - y_observed) ** 2)


initial_guess = [5.00, 2.50, 2.5, 0.08, 0, 0, 0]

result = minimize(model_function, initial_guess, args=(x2, y2))

parameters = result.x


y_fitted = (
    parameters[0] * np.sin(2 * np.pi * parameters[3] * x2 + parameters[4])
    + parameters[1] * np.sin(2 * np.pi * 3 * parameters[3] * x2 + parameters[5])
    + parameters[2] * np.sin(2 * np.pi * 5 * parameters[3] * x2 + parameters[6])
)

plt.scatter(x2, y2, label="Observed Data", s=1,color="black")
plt.plot(x2, y_fitted, label="Fitted Curve",color="red")


# Using curve fit
from scipy.optimize import curve_fit

def func(x, A1, A2, A3, f, p1, p2, p3):
    return A1 * np.sin(2 * np.pi * f * x + p1) + A2 * np.sin(2 * np.pi * 3 * f * x + p2) + A3 * np.sin(2 * np.pi * 5 * f * x + p3)

guess = (5.00, 0.50, 0.5, 0.3, 0.00, 0.00, 0.00)

popt, pcov = curve_fit(func, x2, y2, p0=guess)

# Generate fitted curve
x_fit2 = np.array(x2)

y_fit2 = func(x_fit2, *popt)

plt.plot(x_fit2, y_fit2, label='Fitted Curve(using curve_fit)', color='red')
plt.legend(loc='upper left')
plt.xlabel('X')
plt.ylabel('Y')
plt.savefig(r"dataset2Fig.png")

print("Fitted Parameters:")
print("A1:", parameters[0])
print("A2:", parameters[1])
print("A3:", parameters[2])
print("f:", parameters[3]) 
print("P1:", parameters[4]) 
print("P2:", parameters[5]) 
print("P3:", parameters[6])