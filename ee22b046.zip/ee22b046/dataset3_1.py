import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit


x, y = np.loadtxt("dataset3.txt", unpack=True)
x=np.array(x)
y=np.array(y)
h = 6.62607015e-34  # Planck's constant in J·s
k_B = 1.380649e-23  # Boltzmann's constant in J/K
c =  299792458
def intensity(f,T):
  I=(2 * h * f*3) / ((c*2) * (1 / (np.exp((h * f) / (k_B * T)) - 1)))
  return I
T_guess=5000
popt,pcov=curve_fit(intensity,x,y,T_guess)
plt.scatter(x, y, label='Actual Data', s=1)
plt.plot(x, intensity(x, *popt), color='red')
plt.xlabel('Frequency')
plt.ylabel('Intensity')

print("Estimated Temperature:", popt[0], "K")