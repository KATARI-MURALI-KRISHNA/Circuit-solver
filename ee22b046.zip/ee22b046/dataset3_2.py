import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

# Load data from the simulation
x_data, y_data = np.loadtxt("dataset3.txt", unpack=True)

# Constants and initial guess for the second solution
h_guess = 12.84e-34
k_B_guess = 0.80e-23
c_guess = 319000000
initial_guess_T = 2880

# Model function for the second solution
def planck_equation(f, h, k_B, c, T):
    return (2 * h * f*3) / (c*2) * (1 / (np.exp((h * f) / (k_B * T)) - 1))

# Initial guesses for curve fitting in the second solution
initial_guesses = [h_guess, k_B_guess, c_guess, initial_guess_T]

# Perform curve fitting for the second solution
popt, pcov = curve_fit(planck_equation, x_data, y_data, p0=initial_guesses)


# Plotting the results
plt.scatter(x_data, y_data, label='Actual Data', s=1)
plt.plot(x_data, planck_equation(x_data, *popt), label='Fitted Curve (Second Solution)', color='r')
plt.xlabel('Frequency')
plt.ylabel('Intensity')
plt.legend()
plt.savefig(r'dataset3_2Fig.png')

# Display the results
print("Second Solution - Estimated Constants and Temperature:")
print("   Planck's constant (h):", popt[0], "J·s")
print("   Boltzmann's constant (k_B):", popt[1], "J/K")
print("   Speed of light (c):", popt[2], "m/s")
print("   Temperature (T):", popt[3], "K")