excecute every py-code with command:
python3 filename.py