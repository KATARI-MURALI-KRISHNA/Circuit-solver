import numpy as np
import matplotlib.pyplot as plt
#import numpy.linalg as nplinalg

x, y = np.loadtxt("dataset1.txt", unpack=True)
def st_line(m,x,c):
  return m*x+c
#msg=input("enter your string \n")

x=np.array(x)
y=np.array(y)
#n = 1 * np.random.randn(len(x_list))
# Use column_stack to put the vectors side by side
M = np.vstack([x, np.ones(len(x))]).T
# Use the lstsq function to solve for p_1 and p_2



y1=y[:, np.newaxis]
#for j in range(len(y_list)):
  #k=float(tuple[1][j])+n[j]
  #yn.append(k)
p= np.linalg.lstsq(M,y1,rcond=None)[0]
print(f"The estimated equation is {p[0]} t + {p[1]}")
yest = st_line(x, p[0], p[1])
plt.scatter(np.array(x),np.array(y),s=1)
plt.plot(np.array(x),np.array(yest),color="red")
x_error=x[::25]
y_error=y[::25]
error=abs(y-yest)
plt.errorbar(x_error,y_error,error[::25],color="black",fmt="|")
  
#plt.plot(np.array(x_list),np.array(y_list),np.array(x_list),np.array(yn))


  